java -jar SECURE_CHAT.jar
